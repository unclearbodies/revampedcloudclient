package dev.cloudmc.feature.mod.impl;

import dev.cloudmc.Cloud;
import dev.cloudmc.feature.mod.Mod;
import dev.cloudmc.feature.mod.Type;
import dev.cloudmc.feature.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import java.awt.Color;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.client.renderer.entity.RenderManager;

public class HitboxOnlyMod extends Mod {

    public HitboxOnlyMod() {
        super(
                "HitboxOnly",
                "Hides player models and renders a hitbox.",
                Type.Visual
        );

        Cloud.INSTANCE.settingManager.addSetting(new Setting("Outline Color", this, new Color(255, 0, 0), new Color(255, 0, 0), 0, new float[]{0, 0}));
        Cloud.INSTANCE.settingManager.addSetting(new Setting("Line Width", this, 1.0f, 5.0f, 2.0f));
        Cloud.INSTANCE.settingManager.addSetting(new Setting("Render Fill", this, true));
        Cloud.INSTANCE.settingManager.addSetting(new Setting("Fill Opacity", this, 0.0f, 1.0f, 0.0f));
        Cloud.INSTANCE.settingManager.addSetting(new Setting("Fill Color", this, new Color(0, 0, 0), new Color(0, 0, 0), 0, new float[]{0, 0}));
    }

    @SubscribeEvent
    public void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        if (!isToggled()) return;

        EntityPlayer player = event.entityPlayer;
        if (player == Minecraft.getMinecraft().thePlayer) return; // Don't affect the local player

        event.setCanceled(true); // Cancel normal rendering

        RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
        double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * event.partialRenderTick - renderManager.viewerPosX;
        double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * event.partialRenderTick - renderManager.viewerPosY;
        double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * event.partialRenderTick - renderManager.viewerPosZ;

        AxisAlignedBB bbox = player.getEntityBoundingBox().offset(-player.posX, -player.posY, -player.posZ).offset(x, y, z);

        Color outlineColor = Cloud.INSTANCE.settingManager.getSettingByModAndName(this.getName(), "Outline Color").getColor();
        float lineWidth = Cloud.INSTANCE.settingManager.getSettingByModAndName(this.getName(), "Line Width").getCurrentNumber();
        boolean renderFill = Cloud.INSTANCE.settingManager.getSettingByModAndName(this.getName(), "Render Fill").isCheckToggled();
        float fillOpacity = Cloud.INSTANCE.settingManager.getSettingByModAndName(this.getName(), "Fill Opacity").getCurrentNumber();
        Color fillColor = Cloud.INSTANCE.settingManager.getSettingByModAndName(this.getName(), "Fill Color").getColor();

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.depthMask(false);
        // Optional ESP (Depth testing is left on unless disabled)
        GlStateManager.disableDepth();

        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (renderFill && fillOpacity > 0.0f) {
            GlStateManager.color(fillColor.getRed() / 255.0f, fillColor.getGreen() / 255.0f, fillColor.getBlue() / 255.0f, fillOpacity);
            drawFilledBox(bbox);
        }

        GlStateManager.color(outlineColor.getRed() / 255.0f, outlineColor.getGreen() / 255.0f, outlineColor.getBlue() / 255.0f, 1.0f);
        GL11.glLineWidth(lineWidth);
        RenderGlobal.drawSelectionBoundingBox(bbox);

        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void drawFilledBox(AxisAlignedBB bb) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);
        
        worldRenderer.pos(bb.minX, bb.minY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.minY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.minY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.minX, bb.minY, bb.maxZ).endVertex();

        worldRenderer.pos(bb.minX, bb.maxY, bb.minZ).endVertex();
        worldRenderer.pos(bb.minX, bb.maxY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.minZ).endVertex();

        worldRenderer.pos(bb.minX, bb.minY, bb.minZ).endVertex();
        worldRenderer.pos(bb.minX, bb.maxY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.minY, bb.minZ).endVertex();

        worldRenderer.pos(bb.maxX, bb.minY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.minZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.minY, bb.maxZ).endVertex();

        worldRenderer.pos(bb.minX, bb.minY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.minY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.maxX, bb.maxY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.minX, bb.maxY, bb.maxZ).endVertex();

        worldRenderer.pos(bb.minX, bb.minY, bb.minZ).endVertex();
        worldRenderer.pos(bb.minX, bb.minY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.minX, bb.maxY, bb.maxZ).endVertex();
        worldRenderer.pos(bb.minX, bb.maxY, bb.minZ).endVertex();

        tessellator.draw();
    }
}
